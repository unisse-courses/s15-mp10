# StarRating
-----------------***************---------------------------

This rating is created using a basic javascript and html

-----------------***************---------------------------
